/*
 * This is a stub header for gcd.s
 */
extern int gcd(int a, int b);
